import React, { useState } from 'react';
import { 
  Folder, 
  FileCode, 
  Terminal, 
  BookOpen, 
  Check, 
  Copy, 
  Server, 
  Radio, 
  Layers, 
  ShieldCheck, 
  Zap,
  ChevronRight,
  Code
} from 'lucide-react';

interface ProjectFile {
  id: string;
  name: string;
  path: string;
  category: 'config' | 'server' | 'client' | 'command' | 'test' | 'doc';
  description: string;
  content: string;
}

const FILES: ProjectFile[] = [
  {
    id: 'pom',
    name: 'pom.xml',
    path: 'JavaRemote/pom.xml',
    category: 'config',
    description: 'Maven configuration for Java 17, packaging, and JUnit 5 dependencies.',
    content: `<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.javaremote</groupId>
    <artifactId>javaremote</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>jar</packaging>

    <name>JavaRemote</name>
    <description>Base modular para comunicacao remota cliente-servidor via sockets TCP</description>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <junit.version>5.10.2</junit.version>
    </properties>

    <dependencies>
        <!-- JUnit 5 para testes unitarios -->
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter-api</artifactId>
            <version>\${junit.version}</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter-engine</artifactId>
            <version>\${junit.version}</version>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <!-- Compilador Maven -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>

            <!-- Geracao de JAR executavel -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-jar-plugin</artifactId>
                <version>3.3.0</version>
                <configuration>
                    <archive>
                        <manifest>
                            <mainClass>com.javaremote.Main</mainClass>
                        </manifest>
                    </archive>
                </configuration>
            </plugin>

            <!-- Plugin para execucao direta via Maven -->
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <version>3.1.1</version>
                <configuration>
                    <mainClass>com.javaremote.Main</mainClass>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>`
  },
  {
    id: 'config',
    name: 'Config.java',
    path: 'JavaRemote/src/main/java/com/javaremote/config/Config.java',
    category: 'config',
    description: 'Centralizes network settings with fallback resolution from environment/system properties.',
    content: `package com.javaremote.config;

/**
 * Centralized application configuration.
 * Reads properties from environment variables or system properties with safe default fallbacks.
 */
public final class Config {

    public static final String DEFAULT_HOST = "127.0.0.1";
    public static final int DEFAULT_PORT = 5000;
    public static final int DEFAULT_THREAD_POOL_SIZE = 10;
    public static final int DEFAULT_SO_TIMEOUT_MS = 0; // 0 = infinite timeout

    private final String host;
    private final int port;
    private final int threadPoolSize;

    public Config() {
        this(resolveHost(), resolvePort(), resolveThreadPoolSize());
    }

    public Config(String host, int port) {
        this(host, port, DEFAULT_THREAD_POOL_SIZE);
    }

    public Config(String host, int port, int threadPoolSize) {
        this.host = (host == null || host.isBlank()) ? DEFAULT_HOST : host.trim();
        this.port = (port > 0 && port <= 65535) ? port : DEFAULT_PORT;
        this.threadPoolSize = (threadPoolSize > 0) ? threadPoolSize : DEFAULT_THREAD_POOL_SIZE;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public int getThreadPoolSize() {
        return threadPoolSize;
    }

    private static String resolveHost() {
        String envHost = System.getenv("JAVAREMOTE_HOST");
        if (envHost != null && !envHost.isBlank()) {
            return envHost;
        }
        return System.getProperty("javaremote.host", DEFAULT_HOST);
    }

    private static int resolvePort() {
        String envPort = System.getenv("JAVAREMOTE_PORT");
        if (envPort != null && !envPort.isBlank()) {
            try {
                return Integer.parseInt(envPort.trim());
            } catch (NumberFormatException ignored) {
            }
        }
        String sysPort = System.getProperty("javaremote.port");
        if (sysPort != null && !sysPort.isBlank()) {
            try {
                return Integer.parseInt(sysPort.trim());
            } catch (NumberFormatException ignored) {
            }
        }
        return DEFAULT_PORT;
    }

    private static int resolveThreadPoolSize() {
        String envThreads = System.getenv("JAVAREMOTE_THREADS");
        if (envThreads != null && !envThreads.isBlank()) {
            try {
                return Integer.parseInt(envThreads.trim());
            } catch (NumberFormatException ignored) {
            }
        }
        return DEFAULT_THREAD_POOL_SIZE;
    }

    @Override
    public String toString() {
        return "Config{host='" + host + "', port=" + port + ", threadPoolSize=" + threadPoolSize + "}";
    }
}`
  },
  {
    id: 'command',
    name: 'Command.java',
    path: 'JavaRemote/src/main/java/com/javaremote/command/Command.java',
    category: 'command',
    description: 'Interface contract for server command execution abstraction.',
    content: `package com.javaremote.command;

/**
 * Functional abstraction representing a command that can be executed on the server.
 */
public interface Command {

    /**
     * Returns the unique identifier/name for this command (e.g. "ping").
     *
     * @return lowercase command name
     */
    String getName();

    /**
     * Executes the command with the provided arguments and returns a response string.
     *
     * @param args optional arguments passed after the command name
     * @return response message to be sent back to the client
     */
    String execute(String[] args);
}`
  },
  {
    id: 'ping-command',
    name: 'PingCommand.java',
    path: 'JavaRemote/src/main/java/com/javaremote/command/PingCommand.java',
    category: 'command',
    description: 'Implements the ping command returning pong for health verification.',
    content: `package com.javaremote.command;

/**
 * Basic health check command. Responds with "pong" when "ping" is received.
 */
public class PingCommand implements Command {

    @Override
    public String getName() {
        return "ping";
    }

    @Override
    public String execute(String[] args) {
        return "pong";
    }
}`
  },
  {
    id: 'registry',
    name: 'CommandRegistry.java',
    path: 'JavaRemote/src/main/java/com/javaremote/command/CommandRegistry.java',
    category: 'command',
    description: 'Thread-safe registry that parses raw input lines and routes them to matching commands.',
    content: `package com.javaremote.command;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry and dispatcher for executing registered commands.
 */
public class CommandRegistry {

    private final Map<String, Command> commands = new ConcurrentHashMap<>();

    public CommandRegistry() {
        // Register default built-in commands
        register(new PingCommand());
    }

    public void register(Command command) {
        if (command != null && command.getName() != null) {
            commands.put(command.getName().toLowerCase().trim(), command);
        }
    }

    public String processInput(String rawInput) {
        if (rawInput == null || rawInput.isBlank()) {
            return "ERROR: Empty command received.";
        }

        String[] tokens = rawInput.trim().split("\\\\s+");
        String commandName = tokens[0].toLowerCase();
        String[] args = (tokens.length > 1) ? Arrays.copyOfRange(tokens, 1, tokens.length) : new String[0];

        Command command = commands.get(commandName);
        if (command != null) {
            try {
                return command.execute(args);
            } catch (Exception e) {
                return "ERROR: Command execution failed: " + e.getMessage();
            }
        }

        return "ERROR: Unknown command '" + commandName + "'. Available: " + String.join(", ", commands.keySet());
    }

    public boolean hasCommand(String commandName) {
        return commandName != null && commands.containsKey(commandName.toLowerCase().trim());
    }
}`
  },
  {
    id: 'connection-handler',
    name: 'ConnectionHandler.java',
    path: 'JavaRemote/src/main/java/com/javaremote/connection/ConnectionHandler.java',
    category: 'server',
    description: 'Manages socket I/O lifecycle, streaming input lines, and clean disconnection per client.',
    content: `package com.javaremote.connection;

import com.javaremote.command.CommandRegistry;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Handles the full communication lifecycle for an individual connected TCP client.
 */
public class ConnectionHandler implements Runnable {

    private final Socket clientSocket;
    private final CommandRegistry commandRegistry;
    private final String clientAddress;

    public ConnectionHandler(Socket clientSocket, CommandRegistry commandRegistry) {
        this.clientSocket = clientSocket;
        this.commandRegistry = commandRegistry;
        this.clientAddress = clientSocket.getRemoteSocketAddress() != null
                ? clientSocket.getRemoteSocketAddress().toString()
                : "unknown";
    }

    @Override
    public void run() {
        System.out.println("[+] Client connected: " + clientAddress);

        try (
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(clientSocket.getInputStream(), StandardCharsets.UTF_8));
                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true, StandardCharsets.UTF_8)
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                String input = line.trim();
                if (input.isEmpty()) {
                    continue;
                }

                if ("exit".equalsIgnoreCase(input) || "quit".equalsIgnoreCase(input)) {
                    writer.println("BYE: Connection closed.");
                    break;
                }

                String response = commandRegistry.processInput(input);
                writer.println(response);
            }
        } catch (IOException e) {
            System.err.println("[-] Communication error with client " + clientAddress + ": " + e.getMessage());
        } finally {
            closeSocket();
            System.out.println("[-] Client disconnected: " + clientAddress);
        }
    }

    private void closeSocket() {
        if (clientSocket != null && !clientSocket.isClosed()) {
            try {
                clientSocket.close();
            } catch (IOException ignored) {
            }
        }
    }
}`
  },
  {
    id: 'server',
    name: 'RemoteServer.java',
    path: 'JavaRemote/src/main/java/com/javaremote/server/RemoteServer.java',
    category: 'server',
    description: 'Multi-threaded TCP server with ExecutorService thread pool and graceful shutdown.',
    content: `package com.javaremote.server;

import com.javaremote.command.CommandRegistry;
import com.javaremote.config.Config;
import com.javaremote.connection.ConnectionHandler;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Multi-threaded TCP server that accepts and handles remote client connections.
 */
public class RemoteServer {

    private final Config config;
    private final CommandRegistry commandRegistry;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private ServerSocket serverSocket;
    private ExecutorService threadPool;

    public RemoteServer(Config config) {
        this.config = config != null ? config : new Config();
        this.commandRegistry = new CommandRegistry();
    }

    public RemoteServer(int port) {
        this(new Config(Config.DEFAULT_HOST, port));
    }

    public void registerCommand(com.javaremote.command.Command command) {
        this.commandRegistry.register(command);
    }

    /**
     * Starts the server loop in the current thread or blocks until stopped.
     */
    public void start() {
        if (!running.compareAndSet(false, true)) {
            System.out.println("[!] Server is already running.");
            return;
        }

        this.threadPool = Executors.newFixedThreadPool(config.getThreadPoolSize());

        try {
            this.serverSocket = new ServerSocket(config.getPort());
            System.out.println("==================================================");
            System.out.println(" JavaRemote Server started on port: " + config.getPort());
            System.out.println(" Thread pool size: " + config.getThreadPoolSize());
            System.out.println(" Ready to accept client connections...");
            System.out.println("==================================================");

            while (running.get()) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    threadPool.execute(new ConnectionHandler(clientSocket, commandRegistry));
                } catch (IOException e) {
                    if (!running.get()) {
                        break; // Server socket closed intentionally
                    }
                    System.err.println("[!] Error accepting client connection: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("[X] Could not start server on port " + config.getPort() + ": " + e.getMessage());
        } finally {
            stop();
        }
    }

    /**
     * Gracefully stops the server, closes sockets, and terminates the thread pool.
     */
    public void stop() {
        if (!running.compareAndSet(true, false)) {
            return;
        }

        System.out.println("[*] Shutting down JavaRemote Server...");

        if (serverSocket != null && !serverSocket.isClosed()) {
            try {
                serverSocket.close();
            } catch (IOException ignored) {
            }
        }

        if (threadPool != null && !threadPool.isShutdown()) {
            threadPool.shutdown();
            try {
                if (!threadPool.awaitTermination(3, TimeUnit.SECONDS)) {
                    threadPool.shutdownNow();
                }
            } catch (InterruptedException e) {
                threadPool.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        System.out.println("[*] JavaRemote Server stopped successfully.");
    }

    public boolean isRunning() {
        return running.get();
    }

    public int getPort() {
        return config.getPort();
    }
}`
  },
  {
    id: 'client',
    name: 'RemoteClient.java',
    path: 'JavaRemote/src/main/java/com/javaremote/client/RemoteClient.java',
    category: 'client',
    description: 'TCP client socket manager with AutoCloseable support and transmission methods.',
    content: `package com.javaremote.client;

import com.javaremote.config.Config;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * TCP client responsible for connecting to a JavaRemote server, sending commands, and receiving responses.
 */
public class RemoteClient implements AutoCloseable {

    private final String host;
    private final int port;
    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private boolean connected;

    public RemoteClient() {
        Config config = new Config();
        this.host = config.getHost();
        this.port = config.getPort();
    }

    public RemoteClient(String host, int port) {
        this.host = (host == null || host.isBlank()) ? Config.DEFAULT_HOST : host.trim();
        this.port = (port > 0 && port <= 65535) ? port : Config.DEFAULT_PORT;
    }

    /**
     * Connects to the remote server.
     *
     * @throws IOException if the connection fails
     */
    public void connect() throws IOException {
        if (connected) {
            return;
        }

        System.out.println("[*] Connecting to JavaRemote Server at " + host + ":" + port + "...");
        this.socket = new Socket(host, port);
        this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        this.writer = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.UTF_8);
        this.connected = true;
        System.out.println("[+] Successfully connected to server at " + host + ":" + port);
    }

    /**
     * Sends a command or message to the server and returns the server's response.
     *
     * @param command string command to send (e.g. "ping")
     * @return response from the server, or null if disconnected
     * @throws IOException on transmission failure
     */
    public String sendCommand(String command) throws IOException {
        if (!connected || socket == null || socket.isClosed()) {
            throw new IOException("Client is not connected to a server.");
        }

        if (command == null || command.isBlank()) {
            return null;
        }

        writer.println(command);
        return reader.readLine();
    }

    /**
     * Sends a message without waiting for a return value.
     */
    public void sendMessage(String message) throws IOException {
        if (!connected || writer == null) {
            throw new IOException("Client is not connected to a server.");
        }
        writer.println(message);
    }

    /**
     * Reads a single line response from the server.
     */
    public String receiveMessage() throws IOException {
        if (!connected || reader == null) {
            throw new IOException("Client is not connected to a server.");
        }
        return reader.readLine();
    }

    /**
     * Disconnects from the server and releases all socket and stream resources.
     */
    public void disconnect() {
        connected = false;
        try {
            if (writer != null) {
                writer.close();
            }
        } catch (Exception ignored) {
        }
        try {
            if (reader != null) {
                reader.close();
            }
        } catch (Exception ignored) {
        }
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (Exception ignored) {
        }
        System.out.println("[-] Disconnected from server.");
    }

    @Override
    public void close() {
        disconnect();
    }

    public boolean isConnected() {
        return connected && socket != null && !socket.isClosed();
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }
}`
  },
  {
    id: 'main',
    name: 'Main.java',
    path: 'JavaRemote/src/main/java/com/javaremote/Main.java',
    category: 'server',
    description: 'Unified CLI entry point providing interactive or argument-based launching for Server and Client.',
    content: `package com.javaremote;

import com.javaremote.client.RemoteClient;
import com.javaremote.config.Config;
import com.javaremote.server.RemoteServer;

import java.util.Scanner;

/**
 * Main application entry point.
 * Allows launching either the RemoteServer or the RemoteClient via command line arguments.
 *
 * Usage:
 *   java -jar javaremote.jar server [port]
 *   java -jar javaremote.jar client [host] [port]
 */
public class Main {

    public static void main(String[] args) {
        if (args.length == 0) {
            printUsageAndPrompt();
            return;
        }

        String mode = args[0].toLowerCase();
        switch (mode) {
            case "server" -> {
                int port = parsePort(args, 1, Config.DEFAULT_PORT);
                Config config = new Config(Config.DEFAULT_HOST, port);
                RemoteServer server = new RemoteServer(config);

                // Add shutdown hook for clean termination (Ctrl+C)
                Runtime.getRuntime().addShutdownHook(new Thread(server::stop));

                server.start();
            }
            case "client" -> {
                String host = args.length > 1 ? args[1] : Config.DEFAULT_HOST;
                int port = parsePort(args, 2, Config.DEFAULT_PORT);
                runInteractiveClient(host, port);
            }
            case "help", "-h", "--help" -> printUsage();
            default -> {
                System.err.println("[!] Unknown mode: '" + mode + "'");
                printUsage();
            }
        }
    }

    private static void printUsageAndPrompt() {
        System.out.println("==================================================");
        System.out.println("             JavaRemote Bootstrap                 ");
        System.out.println("==================================================");
        System.out.println("Choose startup mode:");
        System.out.println("  1. Start Server");
        System.out.println("  2. Start Client");
        System.out.println("  3. Exit");
        System.out.print("\\nEnter choice (1/2/3): ");

        Scanner scanner = new Scanner(System.in);
        if (scanner.hasNextLine()) {
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> {
                    Config config = new Config();
                    RemoteServer server = new RemoteServer(config);
                    Runtime.getRuntime().addShutdownHook(new Thread(server::stop));
                    server.start();
                }
                case "2" -> {
                    Config config = new Config();
                    runInteractiveClient(config.getHost(), config.getPort());
                }
                case "3" -> System.out.println("Exiting JavaRemote.");
                default -> {
                    System.out.println("Invalid selection. Showing CLI usage:");
                    printUsage();
                }
            }
        } else {
            printUsage();
        }
    }

    private static void runInteractiveClient(String host, int port) {
        System.out.println("==================================================");
        System.out.println("           JavaRemote Interactive Client          ");
        System.out.println("==================================================");
        System.out.println("Target: " + host + ":" + port);
        System.out.println("Type 'ping' to test connection, or 'exit' to quit.\\n");

        try (RemoteClient client = new RemoteClient(host, port);
             Scanner scanner = new Scanner(System.in)) {

            client.connect();

            while (client.isConnected()) {
                System.out.print("client> ");
                if (!scanner.hasNextLine()) {
                    break;
                }

                String input = scanner.nextLine().trim();
                if (input.isEmpty()) {
                    continue;
                }

                if ("exit".equalsIgnoreCase(input) || "quit".equalsIgnoreCase(input)) {
                    client.sendMessage("exit");
                    break;
                }

                String response = client.sendCommand(input);
                if (response == null) {
                    System.out.println("[!] Server closed the connection.");
                    break;
                }
                System.out.println("server> " + response);
            }
        } catch (Exception e) {
            System.err.println("[X] Client error: " + e.getMessage());
        }
    }

    private static int parsePort(String[] args, int index, int fallback) {
        if (args.length > index) {
            try {
                return Integer.parseInt(args[index]);
            } catch (NumberFormatException ignored) {
            }
        }
        return fallback;
    }

    private static void printUsage() {
        System.out.println("\\nUsage:");
        System.out.println("  java -jar javaremote.jar server [port]");
        System.out.println("  java -jar javaremote.jar client [host] [port]");
        System.out.println("\\nExamples:");
        System.out.println("  java -jar javaremote.jar server 5000");
        System.out.println("  java -jar javaremote.jar client 127.0.0.1 5000");
    }
}`
  },
  {
    id: 'test',
    name: 'CommandTest.java',
    path: 'JavaRemote/src/test/java/com/javaremote/CommandTest.java',
    category: 'test',
    description: 'JUnit 5 automated tests for PingCommand execution and CommandRegistry case-insensitivity.',
    content: `package com.javaremote;

import com.javaremote.command.CommandRegistry;
import com.javaremote.command.PingCommand;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CommandTest {

    private CommandRegistry registry;

    @BeforeEach
    public void setUp() {
        registry = new CommandRegistry();
    }

    @Test
    public void testPingCommandReturnsPong() {
        PingCommand ping = new PingCommand();
        assertEquals("ping", ping.getName());
        assertEquals("pong", ping.execute(new String[0]));
    }

    @Test
    public void testCommandRegistryProcessesPing() {
        String response = registry.processInput("ping");
        assertEquals("pong", response);
    }

    @Test
    public void testCommandRegistryCaseInsensitive() {
        String response = registry.processInput("PING");
        assertEquals("pong", response);
    }

    @Test
    public void testUnknownCommandReturnsError() {
        String response = registry.processInput("unknown_cmd");
        assertTrue(response.startsWith("ERROR: Unknown command"));
    }

    @Test
    public void testEmptyInputReturnsError() {
        String response = registry.processInput("   ");
        assertTrue(response.startsWith("ERROR: Empty command"));
    }
}`
  },
  {
    id: 'readme',
    name: 'README.md',
    path: 'JavaRemote/README.md',
    category: 'doc',
    description: 'Complete Portuguese guide with compile commands, architecture, and next steps.',
    content: `# JavaRemote

Base modular e limpa para comunicação remota cliente-servidor utilizando sockets TCP em Java 17+.

Consulte a documentação completa no arquivo JavaRemote/README.md no repositório.`
  }
];

export default function App() {
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(FILES[0]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div id="javaremote-app" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <header id="app-header" className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md px-6 py-4 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-600/20 border border-indigo-500/30 text-indigo-400">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-slate-50 tracking-tight">JavaRemote</h1>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                  Java 17 • Maven • TCP Sockets
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Estrutura modular e limpa para comunicação cliente-servidor remota
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              id="copy-all-btn"
              onClick={() => handleCopy(selectedFile.content, 'current-view')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
            >
              {copiedId === 'current-view' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedId === 'current-view' ? 'Copiado!' : 'Copiar Arquivo'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex-1 max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 p-6">
        {/* Left Column: Project Explorer & Quick Actions */}
        <aside id="sidebar-panel" className="lg:col-span-4 flex flex-col gap-5">
          {/* Quick Architecture Overview */}
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm">
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-3">
              <Layers className="w-4 h-4" />
              <span>Arquitetura Modular</span>
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                <Server className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <div>
                  <strong className="text-slate-100 font-semibold">RemoteServer:</strong> Multi-conexões simultâneas via <code className="text-emerald-300">ExecutorService</code>.
                </div>
              </div>
              <div className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                <Radio className="w-4 h-4 text-sky-400 mt-0.5 shrink-0" />
                <div>
                  <strong className="text-slate-100 font-semibold">RemoteClient:</strong> Conector TCP autônomo com suporte a <code className="text-sky-300">AutoCloseable</code>.
                </div>
              </div>
              <div className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800">
                <Zap className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                <div>
                  <strong className="text-slate-100 font-semibold">Command & Registry:</strong> Desacoplamento de comandos (ex: <code className="text-amber-300">ping → pong</code>).
                </div>
              </div>
            </div>
          </div>

          {/* File Explorer Tree */}
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider">
                <Folder className="w-4 h-4 text-amber-400" />
                <span>Arquivos do Projeto ({FILES.length})</span>
              </div>
              <span className="text-[11px] text-slate-400">Maven standard</span>
            </div>

            <div className="space-y-1 overflow-y-auto max-h-[420px] pr-1">
              {FILES.map((file) => {
                const isSelected = selectedFile.id === file.id;
                return (
                  <button
                    key={file.id}
                    id={`file-btn-${file.id}`}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg text-xs transition flex items-center justify-between group cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600/20 text-indigo-200 border border-indigo-500/40 font-medium'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-400 group-hover:text-slate-300'}`} />
                      <span className="truncate">{file.name}</span>
                    </div>
                    <ChevronRight className={`w-3.5 h-3.5 shrink-0 transition ${isSelected ? 'text-indigo-400 translate-x-0.5' : 'text-slate-400 group-hover:text-slate-400'}`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick CLI Commands */}
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>Comandos Maven</span>
            </div>
            <div className="space-y-2 text-[11px] font-mono">
              <div className="p-2 rounded bg-slate-950 border border-slate-800 text-emerald-300">
                # Compilar JAR executável<br />
                <span className="text-slate-200">mvn clean package</span>
              </div>
              <div className="p-2 rounded bg-slate-950 border border-slate-800 text-sky-300">
                # Iniciar Servidor TCP<br />
                <span className="text-slate-200">java -jar target/javaremote-1.0.0-SNAPSHOT.jar server</span>
              </div>
              <div className="p-2 rounded bg-slate-950 border border-slate-800 text-amber-300">
                # Iniciar Cliente Interativo<br />
                <span className="text-slate-200">java -jar target/javaremote-1.0.0-SNAPSHOT.jar client</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Right Column: Code Viewer & File Details */}
        <main id="code-viewer-panel" className="lg:col-span-8 flex flex-col gap-4">
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <Code className="w-4 h-4 text-indigo-400" />
                  <span className="font-mono text-sm font-semibold text-slate-100">{selectedFile.name}</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">{selectedFile.path}</p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-300 max-w-md hidden md:block">
                  {selectedFile.description}
                </span>
                <button
                  id={`copy-code-${selectedFile.id}`}
                  onClick={() => handleCopy(selectedFile.content, selectedFile.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition cursor-pointer shrink-0 shadow-sm"
                >
                  {copiedId === selectedFile.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedId === selectedFile.id ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>
            </div>

            {/* Code Block */}
            <div className="mt-3 rounded-lg bg-slate-950 border border-slate-800/80 overflow-hidden">
              <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto leading-relaxed max-h-[580px] overflow-y-auto">
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>

          {/* Test & Verification Info Banner */}
          <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/20 text-xs text-slate-300 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-100">Pronto para desenvolvimento no IntelliJ, Eclipse ou VS Code</span>
              <p className="text-slate-400 mt-0.5">
                Basta abrir o diretório <code className="text-indigo-300 font-mono">JavaRemote/</code> na sua IDE como projeto Maven existente. Todas as classes seguem os padrões de encapsulamento, I/O seguro com try-with-resources e controle de threads do Java 17.
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
