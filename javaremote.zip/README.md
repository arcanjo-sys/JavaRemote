# JavaRemote

Base modular e limpa para comunicação remota cliente-servidor utilizando sockets TCP em Java 17+.

Consulte a pasta `JavaRemote/` para o projeto Maven completo.

---

## 📁 Estrutura Rápida

- `JavaRemote/pom.xml` — Configuração Maven
- `JavaRemote/src/main/java/com/javaremote/`
  - `Main.java` — CLI universal (Server / Client)
  - `MainServer.java` — Execução direta do Servidor
  - `MainClient.java` — Execução direta do Cliente
  - `client/RemoteClient.java` — Conector TCP cliente
  - `server/RemoteServer.java` — Servidor multithread TCP
  - `connection/ConnectionHandler.java` — Gerenciador de conexão e I/O de cliente
  - `command/Command.java` — Interface base de comando
  - `command/PingCommand.java` — Comando ping -> pong
  - `command/CommandRegistry.java` — Registro de comandos
  - `config/Config.java` — Configurações (Host, Porta, Threads)
- `JavaRemote/src/test/java/com/javaremote/CommandTest.java` — Testes unitários JUnit 5

Para instruções detalhadas de compilação e execução, veja `JavaRemote/README.md`.
